
# Unix Philosophy
- Do one thing and do it well
- Everything is a file
- Small programs connected via pipes

# Kernel vs Shell
Kernel: Core of OS
Shell: Interface between user and kernel

# CLI vs GUI
CLI: Command Line Interface
GUI: Graphical User Interface

# Filesystem Hierarchy
/ root
/home user files
/etc config
/bin binaries
