
pwd
ls
cd ..
mkdir test
rmdir test
touch file.txt
cat file.txt
