
grep "hello" file.txt
find . -name "*.txt"
chmod 755 file.txt
ls -l | grep file
