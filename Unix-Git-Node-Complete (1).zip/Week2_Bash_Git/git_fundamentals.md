
# Git Fundamentals
git init
git clone <repo>
git add .
git commit -m "message"
