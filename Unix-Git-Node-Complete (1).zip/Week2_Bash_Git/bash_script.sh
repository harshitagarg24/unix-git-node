
#!/bin/bash
echo "Enter your name:"
read name
echo "Hello $name"

for i in 1 2 3
do
  echo "Number: $i"
done

if [ $name == "admin" ]
then
  echo "You are admin"
else
  echo "Normal user"
fi
