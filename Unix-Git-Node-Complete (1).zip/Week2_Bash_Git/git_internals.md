
# Git Internals
Working Directory
Staging Area
Repository

git diff
git log
git reset --hard HEAD
