
# Unix, Git & Node.js Complete Practical

This repository contains:
- Unix Philosophy & Commands
- Bash Scripting
- Git Fundamentals & Internals
- GitHub Workflow
- JavaScript Runtime
- Node.js Introduction
- Node Core Modules (fs)

## Run Node App
npm install
npm start
