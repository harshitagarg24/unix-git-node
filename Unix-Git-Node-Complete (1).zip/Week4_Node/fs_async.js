
const fs = require("fs");

fs.writeFile("async.txt", "Hello Async World", (err) => {
    if (err) throw err;

    fs.readFile("async.txt", "utf-8", (err, data) => {
        if (err) throw err;
        console.log(data);
    });
});
