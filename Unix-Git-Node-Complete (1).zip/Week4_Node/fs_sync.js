
const fs = require("fs");

fs.writeFileSync("sync.txt", "Hello Sync World");
const data = fs.readFileSync("sync.txt", "utf-8");

console.log(data);
