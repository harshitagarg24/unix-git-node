
console.log("Start");

setTimeout(() => {
    console.log("Async Task");
}, 2000);

console.log("End");
