
1. Fork repo
2. Create branch
3. Push branch
4. Create Pull Request
5. Code Review
