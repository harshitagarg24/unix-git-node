
git branch feature
git checkout feature
git merge feature
git rebase main
